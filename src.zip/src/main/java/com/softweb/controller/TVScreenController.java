package com.softweb.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.softweb.calculation.Utility;
import com.softweb.pojo.SocketResponse;
import com.softweb.webservice.WebSocketService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Date;

@Controller
@RequestMapping(value = "/")
public class TVScreenController {

    @Autowired
    WebSocketService webSocketService;

    public static String displayTimeFormat = "yyyy-MM-dd HH:mm:ss";

    private static final Logger logger = LoggerFactory.getLogger(TVScreenController.class);

    @GetMapping(value = "/tvscreen")
    public ModelAndView displayTVScreen() throws Exception {
       
    	ModelAndView modelView = new ModelAndView("tvscreen");
    	modelView.addObject("socketResponse", SocketResponse.getSocketResponse());
        modelView.addObject("deviceStatus", new ObjectMapper().writeValueAsString(WebServiceController.deviceStatus));
        modelView.addObject("craneStatusInst", new ObjectMapper().writeValueAsString(WebServiceController.craneStatusInst));
        return modelView;
    }

    @ResponseBody
    @GetMapping(value = "/gettime")
    public String getTime() throws Exception {
        return Utility.dateFormat(new Date(),displayTimeFormat);
    }
}
