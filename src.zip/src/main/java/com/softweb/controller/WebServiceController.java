package com.softweb.controller;

import com.softweb.calculation.Utility;
import com.softweb.mqtt.MessagePublisher;
import com.softweb.mqtt.TimeOutPublisher;
import com.softweb.pojo.CraneStatus;
import com.softweb.pojo.CsvOutput;
import com.softweb.pojo.ResponseMsg;
import com.softweb.pojo.SocketResponse;
import com.softweb.properties.PropertyValuSet;
import com.softweb.webservice.DipOutWebService;
import com.softweb.webservice.SapDataService;
import com.softweb.webservice.WebSocketService;
import com.softweb.writefile.CsvFileExport;
import org.apache.commons.lang.StringUtils;
import org.eclipse.paho.client.mqttv3.*;
import org.jsoup.Connection;
import org.jsoup.Connection.Response;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.InetAddress;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

@RestController
@RequestMapping(value = "/api")
public class WebServiceController implements MqttCallback {

    @Autowired
    WebSocketService webSocketService;

    private static final Logger logger = LoggerFactory.getLogger(WebServiceController.class);

    @Value("${mqtt.clientId}")
    private String mqttClientId;

    @Value("${mqtt.topic}")
    private String mqttTopic;

    @Value("${reapbery.device.ip}")
    private String[] rackIps;

    @Value("${reapbery.device.hooterIp}")
    private String hooterIp;

    @Value("${mqtt.topic.rack}")
    private String rack;

    @Value("${mqtt.topic.totalTopic}")
    private int totalTopic;

    @Value("${mqtt.qos}")
    private int mqttQos;

    @Value("${webservice.dipoutCall}")
    private int dipServiceCall;

    @Value("${webservice.reset.time}")
    private int resetServiceTime;

    @Value("${mqtt.publishTopicForEOT27bulb}")
    public  String publishTopicForBulb14EOT27;

    @Value("${mqtt.publishTopicForEOT26bulb}")
    public  String publishTopicForBulb13EOT26;

    @Value("${mqtt.publishTopic14EOT27}")
    public  String publishTopic14EOT27;

    @Value("${mqtt.publishTopic13EOT26}")
    public  String publishTopic13EOT26;

    @Value("${mqtt.publishBulbMessageIn}")
    public  String publishBulbMessageIn;

    @Value("${mqtt.publishBulbMessageOut}")
    public  String publishBulbMessageOut;

    @Value("${mqtt.maxTimeoutPeriodForDipOut}")
    public  String maxTimeoutPeriodForDipOut;

    private static String template;
    private final AtomicLong counter = new AtomicLong();
    static MqttClient client = null;
    static final MqttConnectOptions connection = new MqttConnectOptions();
    static boolean isDipStart = false;
    static boolean runningProcess = false;
    public static String ponumber;
    public static boolean firstTime = true;
    public static String currentRack = "";
    static boolean isRepeat = false;
    public static int activeDeviceCount = 0;
    public static float buzzerTime;
    public static String rackNo;
    public static CsvOutput csvData;
    public static String dateTimeFormat = "dd-MM-yyyy 'at' HH:mm:ss";
    public static String filenameFormat = "dd-MM-yyyy";
    public static Date inDate;
    public static Date outDate;
    public static Date webserviceCallDate;
    public static Timer timer = null;
    public static Timer timerForDipOut = null;
    public static boolean isDipOut = false;
    public static boolean isProcessFinished = false;
    public static boolean inavalidcall = false;
    public static String topicReceived;
    public static int count = 0;
    static Response response;
//    static InetAddress inetAddress;
//    static boolean isReachable;
    public static String displayTimeFormat = "HH:mm:ss";
    public static Date webserviceRfidCallDate;
    public static String deviceType = "";
    private static boolean refreshData = false;
    private static String inTempGlobal = "";
    private static String outTempGlobal = "";
    public static String reqCoating;
    public static String workOrderNo;
    public static Map<String,String> deviceStatus = new LinkedHashMap<>();
    public static String autoDipOut = "";
    public static CraneStatus craneStatusInst = CraneStatus.getCraneStatusInst();

    @Autowired
    public SapDataService sapDataService;

    /***
     *  Below is webservice for Sending Data to SAP
     *  Client URL  = http://192.168.8.158/pens.asp?UserId=0&Language=0&Device=eZtrend%20GR&
     *  Local URL = http://203.129.212.187/pens.asp?UserId=0&Language=0&Device=eZtrend%20GR
     */

    static final String url ="http://192.168.8.158/pens.asp?UserId=0&Language=0&Device=eZtrend%20GR&";
    //    static final String url = "http://203.129.212.187/pens.asp?UserId=0&Language=0&Device=eZtrend%20GR";

    public WebServiceController() {
        super();
        connection.setCleanSession(true);
        connection.setAutomaticReconnect(true);

    }

    @Override
    public void connectionLost(Throwable arg0) {
        logger.debug("Connection lost, Disconnect Web service Try again..");
        try {
            client.reconnect();
        } catch (MqttException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken arg0) {
        // TODO Auto-generated method stub

    }

     @Override
    public void messageArrived(String topic, MqttMessage msg) throws Exception {    	 
    	String message = null;
    	if(msg!=null) {
            message = new String(msg.getPayload());
        }
        logger.debug(msg + " ---Topic -------- " + topic);
    	if(message!=null) {
            sendCraneStatus(topic, message);
        }
        if (runningProcess) {
            //messageRouter(topic, new String(msg.getPayload()));
            if(message!=null) {
                messageRouter(topic, message);
            }
        }
    }

    @RequestMapping(value = "/dipOut", method = RequestMethod.GET)
    public ResponseMsg analysisStart(@RequestParam(value = "PODOCNo", required = true) String poNumber, @RequestParam(value = "dipSetTime", required = true) Float dipSetTime, @RequestParam(value = "rackNo", required = true) String rackNo,
                                     @RequestParam(value = "workOrder", required = false) String workOrder,
                                     @RequestParam(value = "requiredCoating", required = false) String requiredCoating,
                                     @RequestParam(value = "sourceType", required = true) String sourceType) throws InterruptedException, MqttException {
          try {
            DipOutWebService.sapDataService = sapDataService;
            mqttConnect();
            isProcessFinished = false;
            topicReceived = "";
            isDipOut = false;
            Date currentDate = new Date();
            String sourceTypeName = sourceType.equalsIgnoreCase("r")?"RFID":"Tablet";
            deviceType = sourceTypeName;

            if(refreshData){
                SocketResponse.resetSocketResponse();
                refreshData = false;
            }

            if(ponumber ==null)
            {
                ponumber = "";
            }
            if(!ponumber.equals(poNumber))
            {
                SocketResponse socketResponse = SocketResponse.getSocketResponse();
                socketResponse.setRfidTime("");
                socketResponse.setTabletTime("");
            }

            if(!isDipStart) {
                inDate = null;
                SocketResponse socketResponse = SocketResponse.getSocketResponse();
                if(sourceType.equalsIgnoreCase("r")){
                    webserviceRfidCallDate = currentDate;
                    socketResponse.setRfidTime(Utility.dateFormat(webserviceRfidCallDate, displayTimeFormat));

                } else {
                    webserviceCallDate = currentDate;
                    socketResponse.setTabletTime(Utility.dateFormat(webserviceCallDate, displayTimeFormat));
                }

                ponumber = poNumber;
                buzzerTime= dipSetTime;
                socketResponse.setRackNo(rackNo);
                socketResponse.setPoNumber(poNumber);
                socketResponse.setDipSetTime(String.format("%.2f", buzzerTime));
//              socketResponse.setDipSetTime(String.valueOf(dipSetTime));
                socketResponse.setWorkOrder(workOrder);
                socketResponse.setRequiredCoating(requiredCoating);
                webSocketService.socketInput(socketResponse);
            }
            if (!isProcessFinished) {
                startProcess(dipSetTime, poNumber, rackNo ,workOrder ,requiredCoating);
            }
        } catch (Exception e) {
            logger.error("Web Service Call Errro..", e);
        }
        return new ResponseMsg(counter.incrementAndGet(), template);
    }

    public void startProcess(float dipSetTime, String poNumber, String rackNo, String workOrder, String requiredCoating) {

        if (inDate == null)
            runningProcess = false;
        if (!runningProcess ) {
            runningProcess = true;
            template = "Request received and process start";
            activeDeviceCount = 0;
            WebServiceController.rackNo = rackNo;
            try {
                checkHooterStatus();
                logger.debug("Webservice Call, Process no.:" + poNumber + " Rack No : " + rackNo
                             + " Dipset time:" + dipSetTime + " workOrder:" + workOrder + " required coating:" + requiredCoating + " Type : " + deviceType);
                csvData = new CsvOutput();
                ponumber = poNumber;
                workOrderNo = workOrder;
                reqCoating = requiredCoating;
                buzzerTime = dipSetTime;
                if (client == null) {
                    connectToBroker();
                }
                if (firstTime) {
//                    for (int i = 1; i <= totalTopic; i++) {
//                        //                        logger.debug("Topic subscribe : " + rack + i);
//                        client.subscribe(rack + i, mqttQos);// 2 = QoS
//
//                    }
                    client.subscribe(publishTopic13EOT26,mqttQos);
                    client.subscribe(publishTopic14EOT27,mqttQos);
                    firstTime = false;
                }
                activeDeviceChecker();
            } catch (Exception e) {
                e.printStackTrace();
                logger.error("WebServiceController , Start Process : - ", e);
            }
        } else {
            template = "Process still running wait till complete";
        }
    }

    public void activeDeviceChecker() {
        for (String ip : rackIps) {

            new Thread(new Runnable() {
                public void run() {
                    try {
//                        inetAddress = InetAddress.getByName(ip);
//                        isReachable = inetAddress.isReachable(1000);
//                        System.out.println(ip+"***********"+isReachable);

                        Process p1 = java.lang.Runtime.getRuntime().exec("ping -n 1 "+ip);
                        boolean reachable = p1.waitFor(100,TimeUnit.MILLISECONDS);

                        deviceStatus.put(ip,reachable?"Connected":"Disconnected");
                        if (!reachable) {
                            //NotificationWebservice.notification(ip, "Device ip is Unreachable/Not Working");
                        } else {
                            activeDeviceCount();
                        }

                    } catch (Exception e) {
                        logger.error("WebServiceController", e);
                    }
                }
            }).start();
        }

    }




    public void messageRouter(final String topic, final String msg) {
        try {
            //            logger.debug("Total Active Device :- " + activeDeviceCount);
//            if (activeDeviceCount >= 2) {
                if ("1".equals(msg) && !isDipStart) {
                    dipInStart(topic);
                    // Topic Value
                    if (topic.equals("14EOT27")) {
                        publishMessage(publishBulbMessageIn, publishTopicForBulb14EOT27);
                    } else if (topic.equals("13EOT26")) {
                        publishMessage(publishBulbMessageIn, publishTopicForBulb13EOT26);
                    }
                    startTimerForDipout(topic);
                } else if ("0".equals(msg) && isDipStart && currentRack.equals(topic)) {
                    dipOutStart(topic);
                }
//            } else {
//                if ("1".equals(msg) && !isDipStart) {
//                    dipInStart(topic);
//                    startTimerForDipout(topic);
//                } else if ("0".equals(msg) && isDipStart) {
//                    dipOutStart(topic);
//                }
////                currentRack = null;
//            }

        } catch (Exception e) {
            logger.error("WebServiceController", e);
        }
    }
    
    public void sendCraneStatus(final String topic, final String msg) {
    	try {
    		craneStatusInst = CraneStatus.getCraneStatusInst();
        	if(StringUtils.isNotBlank(topic) && StringUtils.isNotBlank(msg)) {
    	    	if("1".equals(msg)) {
    	    		if(topic.equals("14EOT27")) {
    	    			craneStatusInst.setCrane1Connected(true);
    	    		} else {
    	    			craneStatusInst.setCrane2Connected(true);
    	    		}
    	    	} else if("0".equals(msg)) {
    	    		if(topic.equals("14EOT27")) {
                        if(!WebServiceController.autoDipOut.equals("true")) {
                            craneStatusInst.setCrane1Connected(false);
                        }
    	    		} else {
                        if(!WebServiceController.autoDipOut.equals("true")) {
                            craneStatusInst.setCrane2Connected(false);
                        }
    	    		}
    	    	}
                    webSocketService.craneHighlight(craneStatusInst);
        	}
		} catch (Exception e) {
			logger.error("Error while updating Crane Connectivity status: ", e);
		}
    }


    /**
     * DipIn Process
     * @param topic
     */
    public void dipInStart(String topic) {
        try {
            currentRack = topic;
            topicReceived = topic;
            isDipStart = true;
            logger.debug("*** Dip IN : *** " +topic);
            inDate = new Date();
            inTempGlobal = getTemperature();

            SocketResponse socketResponse = SocketResponse.getSocketResponse();
            socketResponse.setDipInTime(Utility.dateFormat(inDate, displayTimeFormat));
            socketResponse.setRackNo(rackNo);
            if (topic.equals("14EOT27")) {
                socketResponse.setCraneNo("27");
            } else {
                socketResponse.setCraneNo("26");
            }
            socketResponse.setPoNumber(ponumber);
            socketResponse.setDipSetTime(String.format("%.2f", buzzerTime));
//            socketResponse.setDipSetTime(String.valueOf(buzzerTime));
            socketResponse.setDipInTemp(getStringIntTemp(inTempGlobal));
//            socketResponse.setDipInTemp(String.valueOf((int)inTempGlobal));
           /* socketResponse.setInOutDifference("");
            socketResponse.setDipOutTemp("");*/
            socketResponse.setDipOutTimeExpected(Date.from(Instant.now().plusSeconds(Utility.minuteToSecond(buzzerTime))));
            socketResponse.setDipOutTime("");
            webSocketService.socketInput(socketResponse);

            startTimer();
            csvData.setInTemp(inTempGlobal);
            String topicString = "";
            if (topic.equals("14EOT27")) {
                topicString = topic + " - " + rackIps[0];
            } else {
                topicString = topic + " - " + rackIps[1];
            }
            csvData.setTopic(topicString);
            csvData.setCraneNo(topic.equals("14EOT27")?"27":"26");
            csvData.setDipInTime(Utility.dateFormat(inDate, dateTimeFormat));setDeviceStatusForCSV();
        } catch (Exception e) {
            logger.error("WebServiceController", e);
        }
    }

    public String getStringIntTemp(String temp)
    {
        int result = 0;
        String tempResult = "";
        if(temp != null) {
            result = (int) Double.parseDouble(temp);
            tempResult = String.valueOf(result);
        }
        return tempResult;
    }

    public void setDeviceStatusForCSV() {
        List<String> devicesconnectionStatusList = new ArrayList<String>();
        if(deviceStatus.size() >0) {
            deviceStatus.forEach((k,v)->devicesconnectionStatusList.add(k+" - "+v));
        }
        csvData.setDeviceStatus(String.join(",", devicesconnectionStatusList).trim());
    }


    /**
     * Dipout Process
     * @param topic
     * @throws MqttException
     */
    public  void dipOutStart(String topic) throws MqttException {
        if (topic.equals("14EOT27")) {
            publishMessage(publishBulbMessageOut, publishTopicForBulb14EOT27);
        } else if (topic.equals("13EOT26")) {
            publishMessage(publishBulbMessageOut, publishTopicForBulb13EOT26);
        }
        
        if (Utility.dateDifference() <= PropertyValuSet.Timedifference) {
            /*currentRack = lastTopic;*/
            if (activeDeviceCount >= 2)
                isRepeat = true;
            timer.cancel();
            timer.purge();
            timerForDipOut.cancel();
            timerForDipOut.purge();
            
            logger.debug("*** Invalid DipIn ***" + new Date());

            try {
            	SocketResponse socketResponse = SocketResponse.getSocketResponse();
                socketResponse.setDipOutTime("");
                socketResponse.setDipInTime("");
                socketResponse.setDipOutTimeExpected(new Date());
                socketResponse.setInOutDifference("");
                socketResponse.setCraneNo("");
                socketResponse.setDipInTemp("");
                socketResponse.setDipOutTemp("");

                webSocketService.socketInput(socketResponse);
                webSocketService.deviceError("invalid dipIn");

            }
            catch (Exception e)
            {
                e.printStackTrace();;
            }

//            webSocketService.socketInput(socketResponse);

            isProcessFinished = false;
            //            inavalidcall=true;
            isDipStart = false;
        } else {
            logger.debug("*** Dip Out: ***");
            outTempGlobal = getTemperature();
            timerForDipOut.cancel();
            timerForDipOut.purge();
            SocketResponse socketResponse = SocketResponse.getSocketResponse();
            socketResponse.setDipOutTime(Utility.dateFormat(outDate, displayTimeFormat));
            //socketResponse.setDipOutTimeExpected(new Date());
            socketResponse.setDipOutTemp(getStringIntTemp(outTempGlobal));

            String[] inOutDifference = Utility.dateDifference(inDate, outDate).split(":");
            String inOutmin = inOutDifference[0].length()<2?"0"+inOutDifference[0]:inOutDifference[0];
            String inOutsec = inOutDifference[1].length()<2?"0"+inOutDifference[1]:inOutDifference[1];

            socketResponse.setInOutDifference(inOutmin +  ":" + inOutsec);
            try {
                webSocketService.socketInput(socketResponse);
                stopTimer();

            }
            catch (Exception e)
            {
                e.printStackTrace();;
            }
            DipOutAndSaveReport();
            refreshData = true;
        }
    }

    public  void startTimerForDipout(String topic) throws MqttException {
        //if (!isDipOut) {
        	isDipOut=false;
            autoDipOut = "";
            timerForDipOut = new Timer();
            timerForDipOut.schedule(new TimeOutPublisher(client, topic), Date.from(Instant.now().plusSeconds(Utility.minuteToSecond(Integer.parseInt(maxTimeoutPeriodForDipOut)))));
        //}
    }

    /**
     * Get Realtime Tempreture of Dip In and DIp Out
     * @return
     */
    public static String getTemperature() {
        String temp = null;
        Connection siteConnection;
        try {
            siteConnection = Jsoup.connect(url + (new Date()).getTime());
            siteConnection.timeout(10000);
            response = siteConnection.execute();
            if ("OK".equalsIgnoreCase(response.statusMessage())) {
                Document doc = siteConnection.get();
                Elements nextTurns = doc.select("tr:eq(6) td:eq(3)");
                for (Element nextTurn : nextTurns) {
                    temp = nextTurn.text();
                }
            } else {
                logger.debug("Prothon Data not getting...Error code : " + response.statusCode());
            }
        } catch (Exception e) {
            logger.error("WebServiceController", e);
        }
        return temp;
    }

    /**
     * Disconnecting Broker
     * @throws MqttException
     */
    public static void disconnect() throws MqttException {
        try {
            if (client != null) {
                if (client.isConnected()) {
                    
                    //                    inavalidcall=false;
                } else {
                    logger.error("Client Not Connected ..");
                }
            }
        } catch (Exception e) {
            logger.error("WebServiceController", e);
        }finally{
        	buzzerTime = 0;
            ponumber = null;
            runningProcess = false;
            isDipStart = false;
            csvData = null;
            inDate = null;
            outDate = null;
            isDipOut=true;
            autoDipOut = "";
            currentRack = "";
            webserviceCallDate = null;
            webserviceRfidCallDate = null;
        }
    }

    /**
     * Initiilize Hooter Timer when Dip In start
     * @throws MqttException
     */
    public static void startTimer() throws MqttException {
        timer = new Timer();
        timer.schedule(new MessagePublisher(client), Date.from(Instant.now().plusSeconds(Utility.minuteToSecond(buzzerTime))));
    }

    public static void stopTimer() throws MqttException {
       timer.cancel();
    }



    /**
     * Report Save to CSV
     * @throws MqttException
     */

    static void DipOutAndSaveReport() throws MqttException {
        count++;
        isProcessFinished = true;
        //        timerForDipOut.cancel();
        //        timerForDipOut.purge();
        //        timerForDipOut = null;
        isRepeat = false;
        isDipOut = true;
        csvData.setOutTemp(outTempGlobal);

        csvData.setDipOutTime(Utility.dateFormat(outDate, dateTimeFormat));
        csvData.setExpected(Float.toString(buzzerTime));
        csvData.setProcessNo(ponumber);
        csvData.setRequiredCoating(reqCoating);
        csvData.setWorkOrder(workOrderNo);
        csvData.setTabletTime(webserviceCallDate!= null ?Utility.dateFormat(webserviceCallDate, dateTimeFormat):"");
        csvData.setRfidTime(webserviceRfidCallDate != null ?Utility.dateFormat(webserviceRfidCallDate, dateTimeFormat):"");
        DipOutWebService.dipOutWebServiceCall(csvData.getInTemp(), csvData.getOutTemp());
        csvData.setDifference(Utility.dateDifference(inDate, outDate));
        csvData.setAutoDipOut(autoDipOut);
        CsvFileExport.csvWriter(csvData, Utility.dateFormat(inDate, filenameFormat));
        disconnect();
    }

    public synchronized void activeDeviceCount() {
        activeDeviceCount++;
    }




    private void connectToBroker() throws MqttException {
        client = new MqttClient(PropertyValuSet.mqttBrokerAddress, mqttClientId);
        client.setCallback(this);
        client.connect(connection);
    }

    public void checkHooterStatus() {

        try {
//            inetAddress = InetAddress.getByName(hooterIp);//            isReachable = inetAddress.isReachable(1000);
//            String hooterStatus = isReachable?"Connected":"Disconnected";

            Process p1 = java.lang.Runtime.getRuntime().exec("ping -n 1 "+hooterIp);
            boolean reachable = p1.waitFor(100,TimeUnit.MILLISECONDS);
            String hooterStatus = reachable?"Connected":"Disconnected";

            deviceStatus.put(hooterIp,hooterStatus);
//            if (!isReachable) {
//                //NotificationWebservice.notification(hooterIp, "Hooter ip is Unreachable/Not Working");
//            }
            //logger.info("Hooter Status "+hooterIp+" - "+hooterStatus);

        } catch (Exception e) {
            logger.error("WebServiceController ,Hooter Status  : - ", e);
        }
    }



    private static void publishMessage(String bulbStatus, String topic) throws MqttException {
        MqttMessage sendMsg = new MqttMessage(bulbStatus.getBytes());
        sendMsg.setQos(PropertyValuSet.qos);
        sendMsg.setRetained(false);
        client.publish(topic, sendMsg);

    }


    boolean retrying = false;

    public boolean reConnect() {
        if (!retrying) {
            retrying = true;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    for (; ; ) {
                        try {
                            if (!client.isConnected()) {
                                client = new MqttClient(PropertyValuSet.mqttBrokerAddress, mqttClientId);

                                client.connect(connection);
                                //                                new MessagePublisher(client), Date.from(Instant.now().plusSeconds(Utility.minuteToSecond(buzzerTime));
                                Thread.sleep(10000);
                                retrying = true;
                            } else {
                                retrying = false;
                                break;
                            }
                        } catch (MqttException | InterruptedException e) {
                            try {
                                Thread.sleep(10000);
                            } catch (InterruptedException ex) {
                            }
                        }
                    }
                }
            }).start();
        }
        return retrying;
    }
    
    public void mqttConnect() {
		try {
			if (client == null) {
				client = new MqttClient(PropertyValuSet.mqttBrokerAddress, mqttClientId);
				client.setCallback(this);
				client.connect(connection);
			}	
            client.subscribe(publishTopic13EOT26,mqttQos);
            client.subscribe(publishTopic14EOT27,mqttQos);
		} catch (MqttException e) {
			e.printStackTrace();
		}
	}
}
