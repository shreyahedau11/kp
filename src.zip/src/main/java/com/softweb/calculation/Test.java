package com.softweb.calculation;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * Created by arpit.khatri on 1/12/2018.
 */
public class Test {
    private static final String datetimePattern = "dd-MM-yyyy HH:mm:ss";

    public static void main(String a[]){
        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        try {
            Date oldDate = new Date();
            Calendar gcal = new GregorianCalendar();
            gcal.setTime(oldDate);
            gcal.add(Calendar.SECOND, 900);
            Date newDate = gcal.getTime();
            System.out.println(newDate);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
