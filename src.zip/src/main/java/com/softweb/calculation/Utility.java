package com.softweb.calculation;

import com.softweb.controller.WebServiceController;
import com.softweb.properties.PropertyValuSet;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utility {
	
	static SimpleDateFormat ft;
	
	// private static final Logger logger = LoggerFactory.getLogger(Utility.class);
	 
	
	 private static final String[] IP_HEADER_CANDIDATES = {
		        "X-Forwarded-For",
		        "Proxy-Client-IP",
		        "WL-Proxy-Client-IP",
		        "HTTP_X_FORWARDED_FOR",
		        "HTTP_X_FORWARDED",
		        "HTTP_X_CLUSTER_CLIENT_IP",
		        "HTTP_CLIENT_IP",
		        "HTTP_FORWARDED_FOR",
		        "HTTP_FORWARDED",
		        "HTTP_VIA",
		        "REMOTE_ADDR" };
	 
	
	 
	
	public static synchronized String dateFormat(Date date,String format){
		ft = new SimpleDateFormat (format);
		return ft.format(date);
	}

	public static String dateDifference(Date inDate, Date outDate){

	// Code Change
		 long diff = outDate.getTime() - inDate.getTime();
	        long diffSeconds = diff / 1000 % 60;
	        long diffMinutes = diff / (60 * 1000) % 60;
	        /*long diffHours = diff / (60 * 60 * 1000);
	        int diffInDays = (int) ((inDate.getTime() - outDate.getTime()) / (1000 * 60 * 60 * 24));
	        */
	        String difference = Long.toString(diffMinutes)+":"+Long.toString(diffSeconds);

	        return difference;
	}
	
	public static synchronized int differenceInSecond(Date inDate, Date outDate){
		 long diff = outDate.getTime() - inDate.getTime();
	        return (int) (diff / 1000 );
	}
	
	public static synchronized int differenceInMinute(Date inDate, Date outDate){
		 long diff = outDate.getTime() - inDate.getTime();
	        return (int) (diff / (60 * 1000));
	}
	
	public static synchronized int minuteToSecond(float n){
		int second = 0;
		int one = (int) n;
		int two = (int) ((n - Math.floor(n))*100);
		second = (one*60)+(two);
		return second;
	}
	
	
	public static synchronized double limitPrecision(String dblAsString) {
		 int multiplier = (int) Math.pow(10, PropertyValuSet.maxDigitsAfterDecimal);
		    double truncated = (double) ((long) ((Double.parseDouble(dblAsString)) * multiplier)) / multiplier;
		    return truncated;
	}
	
	public static synchronized String getClientIpAddress(HttpServletRequest request) {
	    for (String header : IP_HEADER_CANDIDATES) {
	        String ip = request.getHeader(header);
	        if (ip != null && ip.length() != 0 && !"unknown".equalsIgnoreCase(ip)) {
	            return ip;
	        }
	    }
	    return request.getRemoteAddr();
	}


	public static synchronized int dateDifference(){
		WebServiceController.outDate =  new Date();
	//	Utility.differenceInSecond(WebServiceController.inDate, WebServiceController.outDate);
		return Utility.differenceInSecond(WebServiceController.inDate, WebServiceController.outDate);
	}
	
}
