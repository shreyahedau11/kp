package com.softweb.webservice;


import com.softweb.calculation.Utility;
import com.softweb.controller.WebServiceController;
import com.softweb.pojo.SapData;
import com.softweb.properties.PropertyValuSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.xml.soap.*;
import java.util.Date;

@Service
public class DipOutWebService {

    private static final Logger logger = LoggerFactory.getLogger(DipOutWebService.class);

    public static String dipInTemp;
    public static String dipOutTemp;

	/*@Value("${webservice.dipout.soapEndpointUrl}")
	private static String soapEndpointUrl;
   
	@Value("${webservice.dipout.soapAction}")
	private static String soapAction;*/
	
	
	/*public static void main(String[] args) {
		dipOutWebServiceCall("4.5", 430f, 450f);
		
	}*/

    public static void dipOutWebServiceCall(String inTemp, String outTemp) {

        dipInTemp = inTemp;
        dipOutTemp = outTemp;

        callSoapWebService(PropertyValuSet.outsoapEndpointUrl, PropertyValuSet.outsoapAction);

    }

	/*public static void main(String[] args) {
		
		String soapEndpointUrl = "http://124.124.8.17/WS_Applications/KPTL_WS.asmx?op=update_Galvnising_EndTime";
	    String soapAction = "http://tempuri.org/update_Galvnising_EndTime";
	    
	    callSoapWebService(soapEndpointUrl, soapAction);
	}
	*/

    private static void createSoapEnvelope(SOAPMessage soapMessage, SapData sapData) throws SOAPException {


        SOAPPart soapPart = soapMessage.getSOAPPart();

        // SOAP Envelope
        SOAPEnvelope envelope = soapPart.getEnvelope();


        // SOAP Body
        SOAPBody soapBody = envelope.getBody();

        SOAPElement endTime = soapBody.addChildElement("update_Galvnising_EndTime", "", "http://tempuri.org/");

//        SOAPElement endTime = soapBody.addChildElement("update_Galvnising_EndTime_aaa", "", "http://google.com");

        /* SOAPElement soapBodyElem = soapBody.addChildElement("SAP", myNamespace);*/
        SOAPElement destinationConfig = endTime.addChildElement("destinationconfig");
        //destinationConfig.addTextNode("KPP");
//	        destinationConfig.addTextNode("KPD");
        destinationConfig.addTextNode(sapData.getDestinationConfig());

        SOAPElement poDocNo = endTime.addChildElement("PO_DOCNO");
//	        poDocNo.addTextNode(WebServiceController.ponumber);
        poDocNo.addTextNode(sapData.getProcessNo());

        SOAPElement racNo = endTime.addChildElement("RacNo");
//	        racNo.addTextNode(WebServiceController.rackNo);
        racNo.addTextNode(sapData.getRackNo());


        SOAPElement craneNo = endTime.addChildElement("crane");
//		    craneNo.addTextNode(WebServiceController.rackNo.equals("rack1")?"27":"26");
        craneNo.addTextNode(sapData.getCraneNo());


        SOAPElement estTime = endTime.addChildElement("EST_TIME");
//	        estTime.addTextNode(Float.toString(WebServiceController.buzzerTime));
        estTime.addTextNode(sapData.getEstTime());


        SOAPElement dipInTIme = endTime.addChildElement("DS_TIME_P");
//	        dipInTIme.addTextNode(Utility.dateFormat(WebServiceController.inDate, "HH.mm"));
        dipInTIme.addTextNode(sapData.getDsTimeP());


        SOAPElement dipinTemp = endTime.addChildElement("DS_TEMP");
//	        dipinTemp.addTextNode(dipInTemp);
        dipinTemp.addTextNode(sapData.getDsTemp() != null? sapData.getDsTemp():"");


        SOAPElement dipoutTemp = endTime.addChildElement("DE_TEMP");
//	        dipoutTemp.addTextNode(dipOutTemp);
        dipoutTemp.addTextNode(sapData.getDeTemp() != null? sapData.getDeTemp():"");


        SOAPElement dipOutTime = endTime.addChildElement("DO_TIME_P");
//	        dipOutTime.addTextNode(Utility.dateFormat(WebServiceController.outDate, "HH.mm"));
        dipOutTime.addTextNode(sapData.getDoTimeP());


        SOAPElement actualStartTime = endTime.addChildElement("actual_Start_time");
//	        actualStartTime.addTextNode(Utility.dateFormat(WebServiceController.inDate, "HH:mm:ss"));
        actualStartTime.addTextNode(sapData.getActualStartTime());


        SOAPElement actualEndTime = endTime.addChildElement("actual_end_time");
//	        actualEndTime.addTextNode(Utility.dateFormat(WebServiceController.outDate, "HH:mm:ss"));
        actualEndTime.addTextNode(sapData.getActualEndTime());


        SOAPElement tabTime = endTime.addChildElement("tabtime");
//	        tabTime.addTextNode(WebServiceController.webserviceCallDate != null?Utility.dateFormat(WebServiceController.webserviceCallDate, "HH:mm:ss"):"");
        tabTime.addTextNode(sapData.getTabTime());


        SOAPElement rfidTime = endTime.addChildElement("rfidtime");
//	        rfidTime.addTextNode(WebServiceController.webserviceRfidCallDate != null?Utility.dateFormat(WebServiceController.webserviceRfidCallDate, "HH:mm:ss"):"");
        rfidTime.addTextNode(sapData.getRfidTime());

        SOAPElement date = endTime.addChildElement("DS_DATE");
        date.addTextNode(sapData.getDate());

        SOAPElement plant = endTime.addChildElement("plant");
//	        plant.addTextNode("0010");
        plant.addTextNode(sapData.getPlant());




    }

    private static void callSoapWebService(String soapEndpointUrl, String soapAction) {

        SapData currentSapData = new DipOutWebService().setSapData();
        try {

            // Create SOAP Connection
            SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
            SOAPConnection soapConnection = soapConnectionFactory.createConnection();

            // insert into db file.
//            new DipOutWebService().insertSapData();

            // Send SOAP Message to SOAP Server
            logger.debug("before SOAP Call");

            boolean savecurrent = false;

            if(sapDataService.getSapDataList().size() > 0) {
                for (SapData sapData : sapDataService.getSapDataList()) {
                    SOAPMessage soapResponse = soapConnection.call(createSOAPRequest(soapAction, sapData), soapEndpointUrl);
                    logger.debug("after SAOP call");

                    String soapResponseCode = soapResponse.getSOAPBody().getElementsByTagName("update_Galvnising_EndTimeResult").item(0).getFirstChild().getTextContent();
//                    WebServiceController.csvData.setSapResponse(soapResponseCode);
                    logger.debug("Soap response for process no " + sapData.getProcessNo() + " is ---"  + soapResponseCode);
                    if (soapResponseCode.trim().equals("4") || soapResponseCode.trim().equals("0")) {
                        sapDataService.deleteSapData(sapData);

                        if(savecurrent == false) {
                            soapResponse = soapConnection.call(createSOAPRequest(soapAction, currentSapData), soapEndpointUrl);
                            logger.debug("saving current data");

                            soapResponseCode = soapResponse.getSOAPBody().getElementsByTagName("update_Galvnising_EndTimeResult").item(0).getFirstChild().getTextContent();
                            WebServiceController.csvData.setSapResponse(soapResponseCode);
                            savecurrent = true;

                            logger.debug("Soap response for process no " + currentSapData.getProcessNo() + " is ---"  + soapResponseCode);
                        }

                    } else {
                        logger.debug("from if condition to insert data");
                        sapDataService.insertSapData(currentSapData);
                    }
                }
            }
            else
            {
                SOAPMessage soapResponse = soapConnection.call(createSOAPRequest(soapAction, currentSapData), soapEndpointUrl);
                logger.debug("after SAOP call");

                String soapResponseCode = soapResponse.getSOAPBody().getElementsByTagName("update_Galvnising_EndTimeResult").item(0).getFirstChild().getTextContent();
                WebServiceController.csvData.setSapResponse(soapResponseCode);
                logger.debug("Soap response" + soapResponseCode);

                if (soapResponseCode.trim().equals("4") || soapResponseCode.trim().equals("0")) {
//                    sapDataService.deleteSapData(sapData);
                } else {
                    logger.debug("from else condition to insert data");
                    sapDataService.insertSapData(currentSapData);
                }
            }

            //logger.debug("soap response-"+soapResponse.toString());
            // Print the SOAP Response
            //  soapResponse.writeTo(System.out);

            soapConnection.close();
        } catch (Exception e) {
            logger.debug("from catch block");
            sapDataService.insertSapData(currentSapData);
            System.err.println("\nError occurred while sending SOAP Request to Server!\nMake sure you have the correct endpoint URL and SOAPAction!\n");
            logger.error("DipOutWebService", e);
        }

    }

    private static SOAPMessage createSOAPRequest(String soapAction, SapData sapData) throws Exception {
        MessageFactory messageFactory = MessageFactory.newInstance();
        SOAPMessage soapMessage = messageFactory.createMessage();

        createSoapEnvelope(soapMessage, sapData);

        MimeHeaders headers = soapMessage.getMimeHeaders();
        headers.addHeader("SOAPAction", soapAction);

        soapMessage.saveChanges();

        return soapMessage;
    }

    public DipOutWebService() {
    }

    @Autowired
    public static SapDataService sapDataService;

    public SapData setSapData()
    {
        logger.debug("inside setSapData---" + WebServiceController.ponumber);
        SapData sapData11 = new SapData();
//        sapData11.setSapDataId(1);
        sapData11.setDestinationConfig("KPP");
        sapData11.setProcessNo(WebServiceController.ponumber);
        sapData11.setRackNo(WebServiceController.rackNo);
        sapData11.setCraneNo(WebServiceController.topicReceived.equals("14EOT27") ? "27" : "26");
        sapData11.setEstTime(Float.toString(WebServiceController.buzzerTime));
        sapData11.setDsTimeP(Utility.dateFormat(WebServiceController.inDate, "HH.mm"));
        sapData11.setDsTemp(dipInTemp != null ? dipInTemp : "0");
        sapData11.setDeTemp(dipOutTemp != null ? dipOutTemp :"0");
        sapData11.setDoTimeP(Utility.dateFormat(WebServiceController.outDate, "HH.mm"));
        sapData11.setActualStartTime(Utility.dateFormat(WebServiceController.inDate, "HH:mm:ss"));
        sapData11.setActualEndTime(Utility.dateFormat(WebServiceController.outDate, "HH:mm:ss"));
        sapData11.setTabTime(WebServiceController.webserviceCallDate != null ? Utility.dateFormat(WebServiceController.webserviceCallDate, "HH:mm:ss") : "");
        sapData11.setRfidTime(WebServiceController.webserviceRfidCallDate != null ? Utility.dateFormat(WebServiceController.webserviceRfidCallDate, "HH:mm:ss") : "");
        sapData11.setPlant("0010");
        sapData11.setDate(Utility.dateFormat(WebServiceController.inDate, "dd.MM.yyyy"));

        return sapData11;
    }



}
