package com.softweb.webservice;

import com.softweb.Repository.SapDataDao;
import com.softweb.pojo.SapData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SapDataService {

    private static final Logger logger = LoggerFactory.getLogger(SapDataService.class);

    @Autowired
    private SapDataDao sapDataDao;

    public List<SapData> getSapDataList()
    {
        return sapDataDao.findAll();
    }

    public SapData insertSapData(SapData sapData)
    {
        logger.debug("inserting data------>" + sapData.getProcessNo());
        return sapDataDao.save(sapData);
    }

    public void deleteSapData(SapData sapData){ sapDataDao.delete(sapData);}

}
