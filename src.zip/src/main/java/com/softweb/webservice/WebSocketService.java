package com.softweb.webservice;

import com.softweb.calculation.Utility;
import com.softweb.controller.WebServiceController;
import com.softweb.pojo.CraneStatus;
import com.softweb.pojo.SocketResponse;
import com.softweb.writefile.CsvPiStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class WebSocketService {

    @Autowired
    private SimpMessagingTemplate simpMessagingTemplate;

    @Autowired
    WebServiceController webServiceController;

    public void socketInput(SocketResponse socketResponse) throws Exception {
        this.simpMessagingTemplate.convertAndSend("/topic/tvscreen", socketResponse);
    }

    public void deviceError(String message) throws Exception {
        this.simpMessagingTemplate.convertAndSend("/topic/error", "Error :"+ message);
    }
    
    public void craneHighlight(CraneStatus craneStatus) throws Exception {
            this.simpMessagingTemplate.convertAndSend("/topic/craneStatus", WebServiceController.craneStatusInst);
    }

    @Scheduled(fixedDelay = 1000)
    public void checkActiveDevice() throws Exception {
        webServiceController.checkHooterStatus();
        webServiceController.activeDeviceChecker();
        this.simpMessagingTemplate.convertAndSend("/topic/checkActiveDevice", webServiceController.deviceStatus);
    }


    @Scheduled(fixedDelay = 60000)
    public void saveActiveDeviceReport() throws Exception {
        webServiceController.checkHooterStatus();
        webServiceController.activeDeviceChecker();
        CsvPiStatus.csvWriter(webServiceController.deviceStatus.toString(),Utility.dateFormat(new Date(), "dd-MM-yyyy HH:mm:ss"),Utility.dateFormat(new Date(), "dd-MM-yyyy"));
    }


}
