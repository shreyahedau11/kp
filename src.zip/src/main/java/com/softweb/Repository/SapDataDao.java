package com.softweb.Repository;

import com.softweb.pojo.SapData;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

//@Repository
public interface SapDataDao extends CrudRepository<SapData, String> {

    List<SapData> findAll();

    SapData save(SapData sapData);

    void delete(SapData sapData);

}
