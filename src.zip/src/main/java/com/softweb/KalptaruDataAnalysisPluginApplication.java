package com.softweb;

import com.softweb.controller.WebServiceController;
import com.softweb.properties.PropertyValuSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.core.env.Environment;


import java.io.*;
import java.util.Date;

@SpringBootApplication
@EnableScheduling
public class KalptaruDataAnalysisPluginApplication /* extends SpringBootServletInitializer*/ {
	
	/* @Override
	    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
	        return application.sources(KalptaruDataAnalysisPluginApplication.class);
	    }*/

	private static final Logger logger = LoggerFactory.getLogger(KalptaruDataAnalysisPluginApplication.class);

	@Autowired
	public static Environment env;
	
	public static void main(String[] args) {
		SpringApplication.run(KalptaruDataAnalysisPluginApplication.class, args);
		sytemRestartMessage();
		logger.debug("System restarted");
	}


	public static void sytemRestartMessage()
	{
		try {
			File f = new File(PropertyValuSet.serverrestartFile);
			if(!f.exists()){
				logger.debug("file does not exist");
				f.createNewFile();
			}
				// Open given file in append mode.
				BufferedWriter out = new BufferedWriter(
						new FileWriter(f, true));
				out.newLine();
				out.write("Code Restarted at " + new Date());
				out.close();

		}
		catch (IOException e) {
			logger.debug("inside catch" + e);
		}

	}
}
