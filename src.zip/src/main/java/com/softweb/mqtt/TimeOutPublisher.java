package com.softweb.mqtt;

import com.softweb.controller.WebServiceController;
import com.softweb.properties.PropertyValuSet;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.TimerTask;

public class TimeOutPublisher extends TimerTask  {
	 private static final Logger logger = LoggerFactory.getLogger(TimeOutPublisher.class);
	 static MqttClient client;
	 final static String mqttMsg = "0";
	 static String topic;
	 public TimeOutPublisher(MqttClient client,String str) {
		 TimeOutPublisher.client = client;
		 topic=str;
	}
	 
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			MqttMessage sendMsg = new MqttMessage(mqttMsg.getBytes());
		    sendMsg.setQos(PropertyValuSet.qos);
			sendMsg.setRetained(false);
			if(!WebServiceController.isDipOut) {
				WebServiceController.autoDipOut = "true";
				client.publish(topic, sendMsg);

			}
		} catch (Exception e) {
			logger.error("MessagePublisher", e);
		}
	}

}
