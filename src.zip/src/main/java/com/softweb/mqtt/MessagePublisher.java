package com.softweb.mqtt;

import java.util.Date;
import java.util.TimerTask;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.softweb.properties.PropertyValuSet;

public class MessagePublisher extends TimerTask  {
	 private static final Logger logger = LoggerFactory.getLogger(MessagePublisher.class);
	 static MqttClient client;
	 public MessagePublisher(MqttClient client) {
		 MessagePublisher.client = client;
	}
	@Override
	public void run() {
		try {
			MqttMessage sendMsg = new MqttMessage(PropertyValuSet.publishTopicMessage.getBytes());
		    sendMsg.setQos(PropertyValuSet.qos);
			sendMsg.setRetained(false);
		    client.publish(PropertyValuSet.publishTopic, sendMsg);
	        logger.debug("Hooter start : "+new Date());
		} catch (Exception e) {
			logger.error("MessagePublisher", e);
		}
	}
}
