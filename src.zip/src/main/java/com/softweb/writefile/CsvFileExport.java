package com.softweb.writefile;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.softweb.calculation.Utility;
import com.softweb.pojo.CsvOutput;
import com.softweb.properties.PropertyValuSet;
import org.apache.commons.lang.StringUtils;

public class CsvFileExport {

	 private static final Logger logger = LoggerFactory.getLogger(CsvFileExport.class);
	
	static FileWriter writer;
	static File directory;
	static final List<String> list = new ArrayList<>();
	
	public static void csvWriter(CsvOutput c,String fileName){
		
		try {
				list.clear();
				
				logger.debug("Report Save :: "+c.getDipInTime()+" "+c.getDipOutTime()+" "+c.getInTemp()+" "+c.getOutTemp());
			 	
				String csvFile = fileName+".csv";
			 	
				String filePath = PropertyValuSet.reports+Utility.dateFormat(new Date(), "MMM-yyyy")+"/"+csvFile;
			 	
				directory = new File(PropertyValuSet.reports+Utility.dateFormat(new Date(), "MMM-yyyy"));
				
					if (!directory.exists()){
							directory.mkdirs();
					   }
			 	
					if(!Files.exists(Paths.get(filePath))){
							//for header
							writer = new FileWriter(filePath,true);
						CSVUtils.writeLine(writer, Arrays.asList("SAP Response","Tablet Time","RFID Time","Rack #","Crane #","Process No","Dip-In Time", "Dip-In Temp", "Dip-Out Time","Dip-Out Temp","Difference","SAP-Value","Required-Coating","Auto Dip-Out","Device Status","","","Work-Order"));
						}else{
							writer = new FileWriter(filePath,true);
					   }
			 	
		       

		    /*    List<CsvOutput> csvOutput = Arrays.asList(
		               new CsvOutput("15-9-2017 at 10:59:36", "448", "15-9-2017 at 11:04:21", "450", "4:45")
		        );*/

			list.add(StringUtils.isNotBlank(c.getSapResponse())?c.getSapResponse():"");
			list.add(StringUtils.isNotBlank(c.getTabletTime())?c.getTabletTime():"");
			list.add(StringUtils.isNotBlank(c.getRfidTime())?c.getRfidTime():"");
			list.add(StringUtils.isNotBlank(c.getTopic())?c.getTopic():"");
			list.add(StringUtils.isNotBlank(c.getCraneNo())?c.getCraneNo():"");
			list.add(StringUtils.isNotBlank(c.getProcessNo())?c.getProcessNo():"");
			list.add(StringUtils.isNotBlank(c.getDipInTime())?c.getDipInTime():"");
			list.add(StringUtils.isNotBlank(c.getInTemp())?c.getInTemp():"");
			list.add(StringUtils.isNotBlank(c.getDipOutTime())?c.getDipOutTime():"");
			list.add(StringUtils.isNotBlank(c.getOutTemp())?c.getOutTemp():"");
			list.add(StringUtils.isNotBlank(c.getDifference())?c.getDifference():"");
			list.add(StringUtils.isNotBlank(c.getExpected())?c.getExpected():"");
			list.add(StringUtils.isNotBlank(c.getRequiredCoating())?c.getRequiredCoating():"");
			list.add(StringUtils.isNotBlank(c.getAutoDipOut())?c.getAutoDipOut():"");
			list.add(StringUtils.isNotBlank(c.getDeviceStatus())?c.getDeviceStatus():"");
			list.add(StringUtils.isNotBlank(c.getWorkOrder())?c.getWorkOrder():"");

		            CSVUtils.writeLine(writer, list);

					//try custom separator and quote.
					//CSVUtils.writeLine(writer, list, '|', '\"');
		       

		        writer.flush();
		        writer.close();
		} catch (Exception e) {
			logger.error("CsvFileExport", e);
		}
			
	}

}
