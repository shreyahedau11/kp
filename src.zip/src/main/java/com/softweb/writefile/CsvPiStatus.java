package com.softweb.writefile;

import com.softweb.calculation.Utility;
import com.softweb.properties.PropertyValuSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class CsvPiStatus {


    private static final Logger logger = LoggerFactory.getLogger(CsvPiStatus.class);

    static FileWriter writer;
    static File directory;
    static final List<String> list = new ArrayList<>();

    public static void csvWriter(String deviceStatus,String deviceCheckTime, String fileName){

        try {
            list.clear();

            String csvFile = fileName+".csv";

            String filePath = PropertyValuSet.piReports+Utility.dateFormat(new Date(), "MMM-yyyy")+"/"+csvFile;

            directory = new File(PropertyValuSet.piReports+Utility.dateFormat(new Date(), "MMM-yyyy"));

            if (!directory.exists()){
                directory.mkdirs();
            }

            if(!Files.exists(Paths.get(filePath))){
                //for header
                writer = new FileWriter(filePath,true);
                CSVUtils.writeLine(writer, Arrays.asList("Date Time,Pi Status"));
            }else{
                writer = new FileWriter(filePath,true);
            }

            list.add(deviceCheckTime);
            list.add(deviceStatus);

            CSVUtils.writeLine(writer, list);

            writer.flush();
            writer.close();
        } catch (Exception e) {
            logger.error("CsvFileExport", e);
        }

    }
}
