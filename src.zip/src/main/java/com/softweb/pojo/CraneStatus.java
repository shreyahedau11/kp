package com.softweb.pojo;

public class CraneStatus {
	private Boolean crane1Connected = false ;
	private Boolean crane2Connected = false ;
	
	 private static CraneStatus craneStatus = null;
	    

	    /**
		 * 
		 */
		private CraneStatus() {
			super();
			// TODO Auto-generated constructor stub
		}

	    public static CraneStatus getCraneStatusInst(){
			if (craneStatus == null) {
				craneStatus = new CraneStatus();
		    }
		    return craneStatus;
	    }

	/**
	 * @return the crane1Connected
	 */
	public Boolean getCrane1Connected() {
		return crane1Connected;
	}
	/**
	 * @param crane1Connected the crane1Connected to set
	 */
	public void setCrane1Connected(Boolean crane1Connected) {
		this.crane1Connected = crane1Connected;
	}
	/**
	 * @return the crane2Connected
	 */
	public Boolean getCrane2Connected() {
		return crane2Connected;
	}
	/**
	 * @param crane2Connected the crane2Connected to set
	 */
	public void setCrane2Connected(Boolean crane2Connected) {
		this.crane2Connected = crane2Connected;
	}

}
