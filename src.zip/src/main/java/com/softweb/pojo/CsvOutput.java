package com.softweb.pojo;

public class CsvOutput {

	private String processNo;
	private String dipInTime; //dipIn Or dipOut
	private String InTemp;
	private String dipOutTime;
	private String outTemp;
	private String difference;
	private String expected;
	private String topic;
	private String tabletTime;
	private String rfidTime;
	private String requiredCoating;
	private String workOrder;
	private String craneNo;
	private String deviceStatus;
	private String sapResponse;
	private String autoDipOut;


	public String getAutoDipOut() {
		return autoDipOut;
	}

	public void setAutoDipOut(String autoDipOut) {
		this.autoDipOut = autoDipOut;
	}

	/**
	 * @return the sapResponse
	 */
	public String getSapResponse() {
		return sapResponse;
	}

	/**
	 * @param sapResponse the sapResponse to set
	 */
	public void setSapResponse(String sapResponse) {
		this.sapResponse = sapResponse;
	}

	/**
	 * @return the deviceStatus
	 */
	public String getDeviceStatus() {
		return deviceStatus;
	}

	/**
	 * @param deviceStatus the deviceStatus to set
	 */
	public void setDeviceStatus(String deviceStatus) {
		this.deviceStatus = deviceStatus;
	}

	/**
	 * @return the craneNo
	 */
	public String getCraneNo() {
		return craneNo;
	}

	/**
	 * @param craneNo the craneNo to set
	 */
	public void setCraneNo(String craneNo) {
		this.craneNo = craneNo;
	}

	/**
	 * @return the tabletTime
	 */
	public String getTabletTime() {
		return tabletTime;
	}

	/**
	 * @param tabletTime the tabletTime to set
	 */
	public void setTabletTime(String tabletTime) {
		this.tabletTime = tabletTime;
	}

	/**
	 * @return the rfidTime
	 */
	public String getRfidTime() {
		return rfidTime;
	}

	/**
	 * @param rfidTime the rfidTime to set
	 */
	public void setRfidTime(String rfidTime) {
		this.rfidTime = rfidTime;
	}

	/**
	 * @return the requiredCoating
	 */
	public String getRequiredCoating() {
		return requiredCoating;
	}

	/**
	 * @param requiredCoating the requiredCoating to set
	 */
	public void setRequiredCoating(String requiredCoating) {
		this.requiredCoating = requiredCoating;
	}

	/**
	 * @return the workOrder
	 */
	public String getWorkOrder() {
		return workOrder;
	}

	/**
	 * @param workOrder the workOrder to set
	 */
	public void setWorkOrder(String workOrder) {
		this.workOrder = workOrder;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public String getProcessNo() {
		return processNo;
	}
	public void setProcessNo(String processNo) {
		this.processNo = processNo;
	}
	public String getDipInTime() {
		return dipInTime;
	}
	public void setDipInTime(String dipInTime) {
		this.dipInTime = dipInTime;
	}
	public String getInTemp() {
		return InTemp;
	}
	public void setInTemp(String inTemp) {
		InTemp = inTemp;
	}
	public String getDipOutTime() {
		return dipOutTime;
	}
	public void setDipOutTime(String dipOutTime) {
		this.dipOutTime = dipOutTime;
	}
	public String getOutTemp() {
		return outTemp;
	}
	public void setOutTemp(String outTemp) {
		this.outTemp = outTemp;
	}
	public String getDifference() {
		return difference;
	}
	public void setDifference(String difference) {
		this.difference = difference;
	}
	public String getExpected() {
		return expected;
	}
	public void setExpected(String expected) {
		this.expected = expected;
	}
	
}
