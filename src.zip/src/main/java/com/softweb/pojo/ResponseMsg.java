package com.softweb.pojo;

public class ResponseMsg {

	private final long id;
	private String msg;
	
	public ResponseMsg(long id,String msg){
		this.id = id;
		this.msg = msg;
	}

	
	
	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}


	public long getId() {
		return id;
	}

}
