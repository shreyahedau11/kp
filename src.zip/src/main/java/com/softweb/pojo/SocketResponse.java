package com.softweb.pojo;

import java.util.Date;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;

public class SocketResponse {

    private String rfidTime=null;
    private String tabletTime=null;
    private String poNumber="";
    private String rackNo="";
    private String craneNo="";
    private String dipInTime="";
    private String dipInTemp="";
    private String dipSetTime="";
    private String dipOutTime= "";
    private Date dipOutTimeExpected=null;
    private String dipOutTemp="";
    private String workOrder ="";
    private String requiredCoating = "";
    private String inOutDifference = "";
    
    private static SocketResponse socketResponse = null;
    

    /**
	 * 
	 */
	private SocketResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

    public static SocketResponse getSocketResponse(){
		if (socketResponse == null) {
			socketResponse = new SocketResponse();
	    }
	    return socketResponse;
    }

    public static void resetSocketResponse(){
        socketResponse = null;
    }

    public Date getDipOutTimeExpected() {
        return dipOutTimeExpected;
    }

    public void setDipOutTimeExpected(Date dipOutTimeExpected) {
        this.dipOutTimeExpected = dipOutTimeExpected;
    }

    public String getPoNumber() {
        return poNumber;
    }

    public void setPoNumber(String poNumber) {
        this.poNumber = poNumber;
    }

    public String getRackNo() {
        return rackNo;
    }

    public void setRackNo(String rackNo) {
        this.rackNo = rackNo;
    }

    public String getDipSetTime() {
        return dipSetTime;
    }

    public void setDipSetTime(String dipSetTime) {
        this.dipSetTime = dipSetTime;
    }

    public String getWorkOrder() {
        return workOrder;
    }

    public void setWorkOrder(String workOrder) {
        this.workOrder = workOrder;
    }

    public String getRequiredCoating() {
        return requiredCoating;
    }

    public void setRequiredCoating(String requiredCoating) {
        this.requiredCoating = requiredCoating;
    }

    public String getDipInTime() {
        return dipInTime;
    }

    public void setDipInTime(String dipInTime) {
        this.dipInTime = dipInTime;
    }

    public String getDipOutTime() {
        return dipOutTime;
    }

    public void setDipOutTime(String dipOutTime) {
        this.dipOutTime = dipOutTime;
    }

    public String getInOutDifference() {
        return inOutDifference;
    }

    public void setInOutDifference(String inOutDifference) {
        this.inOutDifference = inOutDifference;
    }

    public String getDipInTemp() {
        return dipInTemp;
    }

    public void setDipInTemp(String dipInTemp) {
        this.dipInTemp = dipInTemp;
    }

    public String getDipOutTemp() {
        return dipOutTemp;
    }

    public void setDipOutTemp(String dipOutTemp) {
        this.dipOutTemp = dipOutTemp;
    }

    public String getRfidTime() {
        return rfidTime;
    }

    public void setRfidTime(String rfidTime) {
        this.rfidTime = rfidTime;
    }

    public String getTabletTime() {
        return tabletTime;
    }

    public void setTabletTime(String tabletTime) {
        this.tabletTime = tabletTime;
    }

    public String getCraneNo() {
        return craneNo;
    }

    public void setCraneNo(String craneNo) {
        this.craneNo = craneNo;
    }
}
