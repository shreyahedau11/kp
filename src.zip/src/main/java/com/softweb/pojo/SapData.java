package com.softweb.pojo;

import javax.persistence.*;

@Entity
@Table(name="SapData")
public class SapData {

    @Id
    @Column(name = "sap_data_id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Basic
    private int sapDataId;

    private String destinationConfig;
    private String processNo;
    private String rackNo;
    private String craneNo;
    private String estTime;
    private String dsTimeP;
    private String dsTemp;
    private String deTemp;
    private String doTimeP;
    private String actualStartTime;
    private String actualEndTime;
    private String tabTime;
    private String rfidTime;
    private String plant;
    private String date;

    public int getSapDataId() {
        return sapDataId;
    }

    public void setSapDataId(int sapDataId) {
        this.sapDataId = sapDataId;
    }

    public String getDestinationConfig() {
        return destinationConfig;
    }

    public void setDestinationConfig(String destinationConfig) {
        this.destinationConfig = destinationConfig;
    }

    public String getProcessNo() {
        return processNo;
    }

    public void setProcessNo(String processNo) {
        this.processNo = processNo;
    }

    public String getCraneNo() {
        return craneNo;
    }

    public void setCraneNo(String craneNo) {
        this.craneNo = craneNo;
    }

    public String getRackNo() {
        return rackNo;
    }

    public void setRackNo(String rackNo) {
        this.rackNo = rackNo;
    }

    public String getEstTime() {
        return estTime;
    }

    public void setEstTime(String estTime) {
        this.estTime = estTime;
    }

    public String getDsTimeP() {
        return dsTimeP;
    }

    public void setDsTimeP(String dsTimeP) {
        this.dsTimeP = dsTimeP;
    }

    public String getDsTemp() {
        return dsTemp;
    }

    public void setDsTemp(String dsTemp) {
        this.dsTemp = dsTemp;
    }

    public String getDeTemp() {
        return deTemp;
    }

    public void setDeTemp(String deTemp) {
        this.deTemp = deTemp;
    }

    public String getDoTimeP() {
        return doTimeP;
    }

    public void setDoTimeP(String doTimeP) {
        this.doTimeP = doTimeP;
    }

    public String getActualStartTime() {
        return actualStartTime;
    }

    public void setActualStartTime(String actualStartTime) {
        this.actualStartTime = actualStartTime;
    }

    public String getActualEndTime() {
        return actualEndTime;
    }

    public void setActualEndTime(String actualEndTime) {
        this.actualEndTime = actualEndTime;
    }

    public String getTabTime() {
        return tabTime;
    }

    public void setTabTime(String tabTime) {
        this.tabTime = tabTime;
    }

    public String getRfidTime() {
        return rfidTime;
    }

    public void setRfidTime(String rfidTime) {
        this.rfidTime = rfidTime;
    }

    public String getPlant() {
        return plant;
    }

    public void setPlant(String plant) {
        this.plant = plant;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
