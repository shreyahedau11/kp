package com.softweb.properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class PropertyValuSet {

    public static String notificationUrl;
    public static String notificationAction;
    public static String outsoapEndpointUrl;
    public static String outsoapAction;
    public static String publishTopic;
    public static int qos;
    public static int Timedifference;
    public static String mqttBrokerAddress;
    public static int maxDigitsAfterDecimal;
    public static String reports;
    public static String publishTopicForBulb14EOT27;
    public static String publishTopicForBulb13EOT26;
    public static String publishTopicMessage;
    public static String serverrestartFile;
    public static String piReports;

    @Value("${serverrestart.file}")
    public void setServerrestartFile(String serverrestartFile) {
        PropertyValuSet.serverrestartFile = serverrestartFile;
    }

    /*	 public static String url;
	 
	 @Value("${local.prothon.url}")
	public void setUrl(String url) {
		PropertyValuSet.url = url;
	}*/


    @Value("${report.file.location}")
    public void setReports(String reports) {
        PropertyValuSet.reports = reports;
    }


    @Value("${webservice.notificationUrl}")
    public void setNotificationUrl(String notificationUrl) {
        PropertyValuSet.notificationUrl = notificationUrl;
    }

    @Value("${webservice.notificationAction}")
    public void setNotificationAction(String notificationAction) {
        PropertyValuSet.notificationAction = notificationAction;
    }


    @Value("${webservice.dipout.outsoapEndpointUrl}")
    public void setOutsoapEndpointUrl(String outsoapEndpointUrl) {
        PropertyValuSet.outsoapEndpointUrl = outsoapEndpointUrl;
    }

    @Value("${webservice.dipout.outsoapAction}")
    public void setOutsoapAction(String outsoapAction) {
        PropertyValuSet.outsoapAction = outsoapAction;
    }


    @Value("${timere.Timedifference}")
    public void setTimedifference(int timedifference) {
        Timedifference = timedifference;
    }

    @Value("${mqtt.publishTopic}")
    public void setPublishTopic(String publishTopic) {
        PropertyValuSet.publishTopic = publishTopic;
    }

    @Value("${mqtt.qos}")
    public void setQos(int qos) {
        PropertyValuSet.qos = qos;
    }

    @Value("${mqtt.broker.mqttBrokerAddress}")
    public void setMqttBrokerAddress(String mqttBrokerAddress) {
        PropertyValuSet.mqttBrokerAddress = mqttBrokerAddress;
    }


    @Value("${calculation.maxDigitsAfterDecimal}")
    public void setMaxDigitsAfterDecimal(int maxDigitsAfterDecimal) {
        PropertyValuSet.maxDigitsAfterDecimal = maxDigitsAfterDecimal;
    }

    @Value("${mqtt.publishTopicForEOT27bulb}")
    public static void setPublishTopicForBulb14EOT27(String publishTopicForBulb14EOT27) {
        PropertyValuSet.publishTopicForBulb14EOT27 = publishTopicForBulb14EOT27;
    }

    @Value("${mqtt.publishTopicForEOT26bulb}")
    public static void setPublishTopicForBulb13EOT26(String publishTopicForBulb13EOT26) {
        PropertyValuSet.publishTopicForBulb13EOT26 = publishTopicForBulb13EOT26;
    }

    @Value("${mqtt.publishTopicMessage}")
    public  void setPublishTopicMessage(String publishTopicMessage) {
        PropertyValuSet.publishTopicMessage = publishTopicMessage;
    }

    @Value("${pireport.file.location}")
    public void setPiReport(String piReports) {
        PropertyValuSet.piReports = piReports;
    }
}
