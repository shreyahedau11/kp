var stompClient = null;
var countdown;
var time;
var timestamp = null;
var interval = 0;

var startmin = 0;
var startsec = 0;
var timer;
var timerstarted = false;
var roundtimerstarted = false;

var invalidDipIn = false;
var stopCountDown = true;


$( document ).ready(function() {
    $("#circular-timer").show();
    $('#clock-round').hide();
    connect();
    countdown =  $("#circular-timer").countdown360({
        seconds     : 0,
    });
    timerUpdates();    
});

function timerUpdates(){
	//console.log("inside timerUpdates");
 $('#circular-timer').show();
 $('#clock-round').hide();

	if($("#dipInTime").text() && !$("#dipOutTime").text()){
	    //console.log("%%%%%% + 1");
    	startIncCounter();
		startroundTimer();
    	//setTimeout(function(){startroundTimer();}, 100);
    } else if($("#dipInTime").text() && $("#dipOutTime").text()){
        //console.log("%%%%%% + 2");
    	stopRoundTimer();
		stopIncCounter();
    } else if(!$("#dipInTime").text() && !$("#dipOutTime").text()){
        //console.log("%%%%%% + 3");
    	stopRoundTimer();
		stopIncCounter();
    }
}

function startroundTimer() {
	//console.log("start Round")
	$('#circular-timer').show();
     $('#clock-round').hide();

	
	if($("#dipInTime").text() && !$("#dipOutTime").text()){
		startTime();
		var totalSpentTime = parseInt(startmin * 60) + parseInt(startsec)
		
		var time1 = $("#dipSetTime").text().split(':')[0] * 60;
		var time2 = $("#dipSetTime").text().split(':')[1]
		     
		var totalTime = parseInt(time1) + parseInt(time2);
		if(totalTime > totalSpentTime){
			roundtimerstarted = true
			time = parseInt(totalTime) - parseInt(totalSpentTime)
			//console.log("timer time---"+time)
			countdown  =  $("#circular-timer").countdown360({
		        seconds     : time
			});
			countdown.settings.seconds = time;
			countdown.start();
		}
	} else { 
		//console.log("timer time----0")
		time = 0;
		countdown =  $("#circular-timer").countdown360({
	        seconds     : time,
	    });
        countdown.settings.seconds = time;
		countdown.start();
		countdown.stop();
	}
}
function stopRoundTimer(){
	//console.log("stop Round")
	if((!$("#dipInTime").text() && !$("#dipOutTime").text())){
    	time = 0;
    	//console.log("stop time-- 0")
    	//console.log("after start 0");
    } else if($("#dipInTime").text() && $("#dipOutTime").text()){
    	
		var totalSpentTime1 = $("#dipInOutDiff").text().split(':')[0] * 60;
		var totalSpentTime2 = $("#dipInOutDiff").text().split(':')[1]
		var totalSpentTime = parseInt(totalSpentTime1) + parseInt(totalSpentTime2);
		
		var time1 = $("#dipSetTime").text().split(':')[0] * 60;
		var time2 = $("#dipSetTime").text().split(':')[1]
		var totalTime = parseInt(time1) + parseInt(time2);
		
		if(totalTime > totalSpentTime){
			time = parseInt(totalTime) - parseInt(totalSpentTime);
		} else {
			time = 0;
			//console.log("stop time-- 0")
		}
	}
	//console.log("stop time---"+time)
	countdown =  $("#circular-timer").countdown360({
        seconds     : time,
    });
    if(!roundtimerstarted){
        countdown.settings.seconds = time;
        countdown.start();
    }
	//console.log("countdown stop---"+time);
	countdown.settings.seconds = time;
	//console.log(countdown.settings.seconds);
	countdown.stop();
	//console.log("after stop---"+time);
	roundtimerstarted = false;

}
function connect() {
//console.log("inside connect");
    var socket = new SockJS('/kalptaru-tvscreen-websocket');
    stompClient = Stomp.over(socket);
    stompClient.connect({}, function (frame) {
        stompClient.subscribe('/topic/tvscreen', function (socketResponse) {
        	displayDetails(JSON.parse(socketResponse.body));
        });
        stompClient.subscribe('/topic/error', function (message) {
            displayError(message.body);
        });
        
        stompClient.subscribe('/topic/craneStatus', function (craneStatusInst) {
        	craneHighlight(craneStatusInst.body);
        });
        
        stompClient.subscribe('/topic/checkActiveDevice', function (message) {
           displayDeviceStatus(message.body);
        });

    });
}

function displayDeviceStatus(deviceStatus)
{
 $("#deviceIpRow th").remove();
 $("#deviceStatusRow td").remove();


var obj = $.parseJSON(deviceStatus);
var deviceStatus ;

$.each(obj, function(key, value){
    var deviceStatus = value === "Connected"?"device-status active" : "device-status";
//    if(key === "192.168.8.12")
    if(key === "10.79.4.156")
    {
         $("#deviceIpRow").append('<th >RFID Reader('+ key+ ')</th>');
    }
    if(key === "192.168.8.13")
    {
    $("#deviceIpRow").append('<th >EOT-26 ('+ key+ ')</th>');
    }
    else if(key === "192.168.8.14")
    {
    $("#deviceIpRow").append('<th >EOT-27 ('+ key+ ')</th>');
    }
//    $("#deviceIpRow").append('<th >'+ key+ '</th>');
    $("#deviceStatusRow").append('<td data-label="'+ key +'"><span class="'+ deviceStatus  + '">'+value+'</span></td>');
});
}

function craneHighlight(craneStatus){
	craneStatus = $.parseJSON(craneStatus);
	if(craneStatus.crane1Connected){
		$('div#crane1').addClass('active');
	} else {
		$('div#crane1').removeClass('active');
	}
	
	if(craneStatus.crane2Connected){
		$('div#crane2').addClass('active');
	} else {
		$('div#crane2').removeClass('active');
	}
}

function displayDetails(socketResponse)
{
    //console.log("inside display details" + socketResponse.poNumber + socketResponse.rackNo+socketResponse.dipSetTime);

    var dipOut = new Date(socketResponse.dipOutTimeExpected) ;
    var dipOutTime1 = (dipOut.getMonth() + 1)  + "/" + dipOut.getDate() + "/" +  dipOut.getFullYear()
                                                                    + " " + dipOut.getHours() + ":" + dipOut.getMinutes() + ":" + dipOut.getSeconds();

//    alert(moment(tabletTime).format('HH:mm:ss'));
//    moment(moment(socketResponse.rfidTime , "HH:mm:ss").toDate()).format('HH:mm:ss')

     $("#rfidTime").text(socketResponse.rfidTime ===null?"":socketResponse.rfidTime);
     $("#tabletTime").text(socketResponse.tabletTime ===null?"" : socketResponse.tabletTime);
     $("#poNumber").text(socketResponse.poNumber);
     $("#rackNo").text(socketResponse.rackNo);
     $("#craneNo").text(socketResponse.craneNo);
     $("#dipInTime").text(socketResponse.dipInTime === null?"":socketResponse.dipInTime);
     $("#dipInTemp").text(socketResponse.dipInTemp);
     $("#dipSetTime").text(socketResponse.dipSetTime === null?"":parseFloat(socketResponse.dipSetTime).toFixed(2).replace(".",":"))
     $("#dipOutTime").text(socketResponse.dipOutTime ===null?"":socketResponse.dipOutTime);
     $("#dipOutTime1").val((socketResponse.dipInTime.trim() === "")?null:dipOutTime1);
     $("#dipOutTemp").text(socketResponse.dipOutTemp);
     $("#workOrder").text(socketResponse.workOrder);
     $("#requiredCoating").text(socketResponse.requiredCoating);
//     $("#dipInOutDiff").text(socketResponse.inOutDifference);
     $("#errorRow").hide();
     $('#min').text( '00');
     $('#sec').text( '00');
     $("#circular-timer").show();
     $('#clock-round').hide();

      var inOutDifference = socketResponse.inOutDifference;
      if(inOutDifference.trim() != "")
      {
          var minutes1 = inOutDifference.split(':')[0];
     	  var seconds1 = inOutDifference.split(':')[1];
     	  var min1 = minutes1.toString().length < 2 ?"0"+minutes1 : minutes1;
     	  var sec1 = seconds1.toString().length < 2 ?"0"+seconds1 : seconds1;
     	 inOutDifference = min1 + ":" + sec1;
      }


      $("#dipInOutDiff").text(inOutDifference);

     invalidDipIn = false;
//     location.reload(true);
     timerUpdates();
}

function displayError(message)
{
    $("#errorRow").show();
    $("#deviceError").text(message);
    $('#min').text("00");
    $('#sec').text("00");
    invalidDipIn = true;
    countdown.settings.seconds = time;
    countdown.start();
    countdown.stop();
    roundtimerstarted = false;
}



function startIncCounter(){
//$("#circular-timer").show();
// $('#clock-round').hide();
	
	timerstarted = true
	$('#min').text( '00');
	$('#sec').text( '00');
	startTime();
	//console.log("start min-"+startmin);
	//console.log("start sec-"+startsec);
	var input = {
    	    year: 0,
    	    month: 0,
    	    day: 0,
    	    hours: 0,
    	    minutes: startmin,
    	    seconds: startsec
    	};
	timestamp = new Date(input.year, input.month, input.day,
	    	input.hours, input.minutes, input.seconds);
	interval = 1;	

	if(timer!=null) {
		try{
			clearInterval(timer);
		}catch(err) {
			
		}
	}
	timer = setInterval(function () {
	    timestamp = new Date(timestamp.getTime() + interval * 1000);
	    var minutes = timestamp.getMinutes()
	    var seconds = timestamp.getSeconds()
	   		$('#min').text( minutes.toString().length < 2 ?"0"+minutes : minutes);
	   		$('#sec').text( seconds.toString().length < 2 ?"0"+seconds : seconds);
	}, 1000);
}

function stopIncCounter(){

	var minutes = 0;
    var seconds = 0;

    invalidDipIn = false;
    if(!timerstarted && $("#dipInTime").text() && $("#dipOutTime").text()){
    	var totalSpentTime1 = $("#dipInOutDiff").text().split(':')[0];
		var totalSpentTime2 = $("#dipInOutDiff").text().split(':')[1];
		$('#min').text(totalSpentTime1.toString().length < 2 ?"0"+totalSpentTime1 : totalSpentTime1);
    	$('#sec').text(totalSpentTime2.toString().length < 2 ?"0"+totalSpentTime2 : totalSpentTime2);
    }
    else if(!$("#dipInTime").text() && !$("#dipOutTime").text()){
      minutes = 0;
      seconds = 0;
    }
    else {
    	if(timestamp){
    		minutes =  timestamp.getMinutes();
    	    seconds =  timestamp.getSeconds();
    	}
    	var totalSpentTime1 = $("#dipInOutDiff").text().split(':')[0];
        var totalSpentTime2 = $("#dipInOutDiff").text().split(':')[1];
        $('#min').text(totalSpentTime1.toString().length < 2 ?"0"+totalSpentTime1 : totalSpentTime1);
        $('#sec').text(totalSpentTime2.toString().length < 2 ?"0"+totalSpentTime2 : totalSpentTime2);
        stopRoundTimer();

    }
    if(timer!=null) {    	
    	try{
			clearInterval(timer);
		}catch(err) {
			
		}	
    }	
	timerstarted = false


}


function startTime(){

//    alert("dip in time" + $("#dipInTime").text() + "dipout time" +  $("#dipOutTime1").val());
	var second = 0;
	var minutes= 0;
	var dipInTime = $("#dipInTime").text();
	var dipOutTime = $("#dipOutTime").text();
	if(dipInTime){
		//console.log("1----"+dipInTime);
		dipInTime = moment(dipInTime , "HH:mm:ss").toDate();
		//console.log("startt----"+dipInTime);
	}
	if(dipOutTime){
		dipOutTime = moment(dipOutTime , "HH:mm:ss").toDate();
		//console.log("end----"+dipOutTime);
	}


	if(dipInTime && !dipOutTime){
        // Get today's date and time
        //var now = new Date().getTime();
		var d;

		$.ajax({type:'GET',url: "/gettime",
		    async: false,
			success: function(result){
			d = result;
	    },
	    error:function() {
	    	alert("Getting error while submitting form....");
	    	}
		});
//		setTimeout(function(){}, 100);
		var now = moment(d, "YYYY-MM-DD HH:mm:ss").toDate();

		if(moment(dipInTime).add(parseFloat($("#dipSetTime").text().replace(":",".")), 'm').toDate() <= now)
        {
                 $("#circular-timer").hide();
                 $('#clock-round').show();
        }
        else
        {
           $("#circular-timer").show();
           $('#clock-round').hide();
        }

		now = now.getTime();

        // Find the distance between now and the count down date
        var distance = now - dipInTime.getTime();

        // Time calculations for days, hours, minutes and seconds
        startmin = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        startsec = Math.floor((distance % (1000 * 60)) / 1000);

	}
	
}
